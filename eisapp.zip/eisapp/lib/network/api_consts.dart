const base = "http://kgkdam.com:3910/kgkapi/";
const base_product = "http://kgkdam.com:2910/kgkapi/";
const download_Report = "http://220.241.20.165:2910/kgk/report/wsrprintapi.htm?reportName";
// const base = "http://10.20.1.41:2910/kgkapi/";
